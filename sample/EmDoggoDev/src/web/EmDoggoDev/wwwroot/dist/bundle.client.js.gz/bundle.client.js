(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["bundle.client"],{

/***/ "./ClientApp/App.vue":
/*!***************************!*\
  !*** ./ClientApp/App.vue ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _App_vue_vue_type_template_id_67a9280a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./App.vue?vue&type=template&id=67a9280a& */ "./ClientApp/App.vue?vue&type=template&id=67a9280a&");
/* harmony import */ var _App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./App.vue?vue&type=script&lang=js& */ "./ClientApp/App.vue?vue&type=script&lang=js&");
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _App_vue_vue_type_template_id_67a9280a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _App_vue_vue_type_template_id_67a9280a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "ClientApp/App.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./ClientApp/App.vue?vue&type=script&lang=js&":
/*!****************************************************!*\
  !*** ./ClientApp/App.vue?vue&type=script&lang=js& ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../node_modules/babel-loader/lib!../node_modules/vue-loader/lib??vue-loader-options!./App.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./ClientApp/App.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./ClientApp/App.vue?vue&type=template&id=67a9280a&":
/*!**********************************************************!*\
  !*** ./ClientApp/App.vue?vue&type=template&id=67a9280a& ***!
  \**********************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_template_id_67a9280a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../node_modules/vue-loader/lib??vue-loader-options!./App.vue?vue&type=template&id=67a9280a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/App.vue?vue&type=template&id=67a9280a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_template_id_67a9280a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_App_vue_vue_type_template_id_67a9280a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./ClientApp/api/endpoints.js":
/*!************************************!*\
  !*** ./ClientApp/api/endpoints.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.enumServiceAgent = exports.dogsServiceAgent = exports.EnumServiceAgent = exports.DogsServiceAgent = void 0;

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

// ------------------------------------------------------------------------------
// <auto-generated>
//     This code was generated by Emeraude Client Builder.
//     Changes to this file may cause incorrect behavior and will be lost if
//     the code is regenerated.
// </auto-generated>
// ------------------------------------------------------------------------------

/**
 * @typedef CreatedResult
 * @property {string} createdEntityId
 */

/**
 * @typedef AddDogCommand
 * @property {string} name
 * @property {number} type
 * @property {number} breed
 */

/**
 * @typedef EnumValueItem
 * @property {string} name
 * @property {number} value
 * @property {string} key
 */
var DogsServiceAgent = /*#__PURE__*/function () {
  function DogsServiceAgent() {
    _classCallCheck(this, DogsServiceAgent);
  }

  _createClass(DogsServiceAgent, [{
    key: "addDog",

    /**
     * DogsApiController/AddDog
     * @param {AddDogCommand} request
     * @param {Object} queryParams
     * @param {Object} headers
     * @returns {Promise}
     */
    value: function addDog(request) {
      var queryParams = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
      var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
      var url = new URL("/api/dogs/add", window.location.origin);

      if (queryParams != null) {
        url.search = new URLSearchParams(queryParams).toString();
      }

      return fetch(url, {
        method: 'POST',
        headers: headers || {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(request),
        credentials: 'include'
      }).then(function (response) {
        return response.json();
      });
    }
  }]);

  return DogsServiceAgent;
}();

exports.DogsServiceAgent = DogsServiceAgent;

var EnumServiceAgent = /*#__PURE__*/function () {
  function EnumServiceAgent() {
    _classCallCheck(this, EnumServiceAgent);
  }

  _createClass(EnumServiceAgent, [{
    key: "getEnumValueList",

    /**
     * EnumApiController/GetEnumValueList
     * @param {string} enumTypeName
     * @param {Object} queryParams
     * @param {Object} headers
     * @returns {Promise}
     */
    value: function getEnumValueList(enumTypeName) {
      var queryParams = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
      var headers = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
      var url = new URL("/api/enums/".concat(enumTypeName), window.location.origin);

      if (queryParams != null) {
        url.search = new URLSearchParams(queryParams).toString();
      }

      return fetch(url, {
        method: 'GET',
        headers: headers || {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        credentials: 'include'
      }).then(function (response) {
        return response.json();
      });
    }
    /**
     * EnumApiController/GetEnumValue
     * @param {string} enumTypeName
     * @param {number} value
     * @param {Object} queryParams
     * @param {Object} headers
     * @returns {Promise}
     */

  }, {
    key: "getEnumValue",
    value: function getEnumValue(enumTypeName, value) {
      var queryParams = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : null;
      var headers = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : null;
      var url = new URL("/api/enums/".concat(enumTypeName, "/").concat(value), window.location.origin);

      if (queryParams != null) {
        url.search = new URLSearchParams(queryParams).toString();
      }

      return fetch(url, {
        method: 'GET',
        headers: headers || {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        credentials: 'include'
      }).then(function (response) {
        return response.json();
      });
    }
  }]);

  return EnumServiceAgent;
}();
/**
 * @type {DogsServiceAgent}
 */


exports.EnumServiceAgent = EnumServiceAgent;
var dogsServiceAgent = new DogsServiceAgent();
/**
 * @type {EnumServiceAgent}
 */

exports.dogsServiceAgent = dogsServiceAgent;
var enumServiceAgent = new EnumServiceAgent();
exports.enumServiceAgent = enumServiceAgent;

/***/ }),

/***/ "./ClientApp/components/forms/EnumBSelect.vue":
/*!****************************************************!*\
  !*** ./ClientApp/components/forms/EnumBSelect.vue ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _EnumBSelect_vue_vue_type_template_id_4a89a4cb_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./EnumBSelect.vue?vue&type=template&id=4a89a4cb&scoped=true& */ "./ClientApp/components/forms/EnumBSelect.vue?vue&type=template&id=4a89a4cb&scoped=true&");
/* harmony import */ var _EnumBSelect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./EnumBSelect.vue?vue&type=script&lang=js& */ "./ClientApp/components/forms/EnumBSelect.vue?vue&type=script&lang=js&");
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _EnumBSelect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _EnumBSelect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _EnumBSelect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _EnumBSelect_vue_vue_type_template_id_4a89a4cb_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _EnumBSelect_vue_vue_type_template_id_4a89a4cb_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "4a89a4cb",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "ClientApp/components/forms/EnumBSelect.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./ClientApp/components/forms/EnumBSelect.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./ClientApp/components/forms/EnumBSelect.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_EnumBSelect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib??vue-loader-options!./EnumBSelect.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./ClientApp/components/forms/EnumBSelect.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_EnumBSelect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_EnumBSelect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_EnumBSelect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_EnumBSelect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_EnumBSelect_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./ClientApp/components/forms/EnumBSelect.vue?vue&type=template&id=4a89a4cb&scoped=true&":
/*!***********************************************************************************************!*\
  !*** ./ClientApp/components/forms/EnumBSelect.vue?vue&type=template&id=4a89a4cb&scoped=true& ***!
  \***********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_EnumBSelect_vue_vue_type_template_id_4a89a4cb_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib??vue-loader-options!./EnumBSelect.vue?vue&type=template&id=4a89a4cb&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/components/forms/EnumBSelect.vue?vue&type=template&id=4a89a4cb&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_EnumBSelect_vue_vue_type_template_id_4a89a4cb_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_EnumBSelect_vue_vue_type_template_id_4a89a4cb_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./ClientApp/components/static-content/HomePageStaticContent.vue":
/*!***********************************************************************!*\
  !*** ./ClientApp/components/static-content/HomePageStaticContent.vue ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _HomePageStaticContent_vue_vue_type_template_id_25af3c4a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HomePageStaticContent.vue?vue&type=template&id=25af3c4a& */ "./ClientApp/components/static-content/HomePageStaticContent.vue?vue&type=template&id=25af3c4a&");
/* harmony import */ var _HomePageStaticContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./HomePageStaticContent.vue?vue&type=script&lang=js& */ "./ClientApp/components/static-content/HomePageStaticContent.vue?vue&type=script&lang=js&");
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _HomePageStaticContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _HomePageStaticContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _HomePageStaticContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _HomePageStaticContent_vue_vue_type_template_id_25af3c4a___WEBPACK_IMPORTED_MODULE_0__["render"],
  _HomePageStaticContent_vue_vue_type_template_id_25af3c4a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "ClientApp/components/static-content/HomePageStaticContent.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./ClientApp/components/static-content/HomePageStaticContent.vue?vue&type=script&lang=js&":
/*!************************************************************************************************!*\
  !*** ./ClientApp/components/static-content/HomePageStaticContent.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_HomePageStaticContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib??vue-loader-options!./HomePageStaticContent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./ClientApp/components/static-content/HomePageStaticContent.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_HomePageStaticContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_HomePageStaticContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_HomePageStaticContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_HomePageStaticContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_HomePageStaticContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./ClientApp/components/static-content/HomePageStaticContent.vue?vue&type=template&id=25af3c4a&":
/*!******************************************************************************************************!*\
  !*** ./ClientApp/components/static-content/HomePageStaticContent.vue?vue&type=template&id=25af3c4a& ***!
  \******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomePageStaticContent_vue_vue_type_template_id_25af3c4a___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib??vue-loader-options!./HomePageStaticContent.vue?vue&type=template&id=25af3c4a& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/components/static-content/HomePageStaticContent.vue?vue&type=template&id=25af3c4a&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomePageStaticContent_vue_vue_type_template_id_25af3c4a___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_HomePageStaticContent_vue_vue_type_template_id_25af3c4a___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./ClientApp/layouts/Footer.vue":
/*!**************************************!*\
  !*** ./ClientApp/layouts/Footer.vue ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Footer_vue_vue_type_template_id_39a21988___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Footer.vue?vue&type=template&id=39a21988& */ "./ClientApp/layouts/Footer.vue?vue&type=template&id=39a21988&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _Footer_vue_vue_type_template_id_39a21988___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Footer_vue_vue_type_template_id_39a21988___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "ClientApp/layouts/Footer.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./ClientApp/layouts/Footer.vue?vue&type=template&id=39a21988&":
/*!*********************************************************************!*\
  !*** ./ClientApp/layouts/Footer.vue?vue&type=template&id=39a21988& ***!
  \*********************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_template_id_39a21988___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../node_modules/vue-loader/lib??vue-loader-options!./Footer.vue?vue&type=template&id=39a21988& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/layouts/Footer.vue?vue&type=template&id=39a21988&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_template_id_39a21988___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Footer_vue_vue_type_template_id_39a21988___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./ClientApp/layouts/Layout.vue":
/*!**************************************!*\
  !*** ./ClientApp/layouts/Layout.vue ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Layout_vue_vue_type_template_id_0d5a00d2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Layout.vue?vue&type=template&id=0d5a00d2& */ "./ClientApp/layouts/Layout.vue?vue&type=template&id=0d5a00d2&");
/* harmony import */ var _Layout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Layout.vue?vue&type=script&lang=js& */ "./ClientApp/layouts/Layout.vue?vue&type=script&lang=js&");
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _Layout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _Layout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Layout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Layout_vue_vue_type_template_id_0d5a00d2___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Layout_vue_vue_type_template_id_0d5a00d2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "ClientApp/layouts/Layout.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./ClientApp/layouts/Layout.vue?vue&type=script&lang=js&":
/*!***************************************************************!*\
  !*** ./ClientApp/layouts/Layout.vue?vue&type=script&lang=js& ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Layout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/babel-loader/lib!../../node_modules/vue-loader/lib??vue-loader-options!./Layout.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./ClientApp/layouts/Layout.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Layout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Layout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Layout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Layout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Layout_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./ClientApp/layouts/Layout.vue?vue&type=template&id=0d5a00d2&":
/*!*********************************************************************!*\
  !*** ./ClientApp/layouts/Layout.vue?vue&type=template&id=0d5a00d2& ***!
  \*********************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Layout_vue_vue_type_template_id_0d5a00d2___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../node_modules/vue-loader/lib??vue-loader-options!./Layout.vue?vue&type=template&id=0d5a00d2& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/layouts/Layout.vue?vue&type=template&id=0d5a00d2&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Layout_vue_vue_type_template_id_0d5a00d2___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Layout_vue_vue_type_template_id_0d5a00d2___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./ClientApp/layouts/Navbar.vue":
/*!**************************************!*\
  !*** ./ClientApp/layouts/Navbar.vue ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Navbar_vue_vue_type_template_id_4f578506___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Navbar.vue?vue&type=template&id=4f578506& */ "./ClientApp/layouts/Navbar.vue?vue&type=template&id=4f578506&");
/* harmony import */ var _Navbar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Navbar.vue?vue&type=script&lang=js& */ "./ClientApp/layouts/Navbar.vue?vue&type=script&lang=js&");
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _Navbar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _Navbar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Navbar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Navbar_vue_vue_type_template_id_4f578506___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Navbar_vue_vue_type_template_id_4f578506___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "ClientApp/layouts/Navbar.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./ClientApp/layouts/Navbar.vue?vue&type=script&lang=js&":
/*!***************************************************************!*\
  !*** ./ClientApp/layouts/Navbar.vue?vue&type=script&lang=js& ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Navbar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/babel-loader/lib!../../node_modules/vue-loader/lib??vue-loader-options!./Navbar.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./ClientApp/layouts/Navbar.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Navbar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Navbar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Navbar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Navbar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Navbar_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./ClientApp/layouts/Navbar.vue?vue&type=template&id=4f578506&":
/*!*********************************************************************!*\
  !*** ./ClientApp/layouts/Navbar.vue?vue&type=template&id=4f578506& ***!
  \*********************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Navbar_vue_vue_type_template_id_4f578506___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../node_modules/vue-loader/lib??vue-loader-options!./Navbar.vue?vue&type=template&id=4f578506& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/layouts/Navbar.vue?vue&type=template&id=4f578506&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Navbar_vue_vue_type_template_id_4f578506___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Navbar_vue_vue_type_template_id_4f578506___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./ClientApp/locales/bg.json":
/*!***********************************!*\
  !*** ./ClientApp/locales/bg.json ***!
  \***********************************/
/*! exports provided: LOGIN, EMAIL, PASSWORD, FORGOT_PASSWORD, DONT_HAVE_A_PROFILE, FULL_NAME, CONFIRM_PASSWORD, REGISTER, ALREADY_HAVE_A_PROFILE, YOUR_REGISTRATION_HAS_BEEN_SUCCESSFULLY_COMPLETED, CHECK_YOUR_EMAIL_FOR_CONFIRMATION_LINK, SWITCH_TO, ENGLISH, BULGARIAN, HOME, DOGS, SHOPS, LOGOUT, OFFERS, DOG_TYPE_HYPOALLERGENIC, DOG_BREED_GERMAN_SPITZ, DOG_BREED_GERMAN_SHEPHERD, DOG_BREED_BULLDOG, DOG_BREED_POODLE, DOG_BREED_LABRADOR_RETRIEVER, DOG_BREED_GOLDEN_RETRIEVER, DOG_BREED_BEAGLE, DOG_BREED_YORKSHIRE_TERRIER, DOG_BREED_DACHSHUND, DOG_BREED_CHIHUAHUA, DOG_BREED_PUG, DOG_BREED_FRENCH_BULLDOG, DOG_BREED_SIBERIAN_HUSKY, DOG_BREED_BOXER, DOG_BREED_AUSTRALIAN_SHEPHERD, DOG_BREED_GREYHOUND, DOG_BREED_ROTTWEILER, DOG_BREED_POMERANIAN, DOG_BREED_DALMATIAN, DOG_BREED_SHIBA_INU, DOG_BREED_SAMOYED, DOG_BREED_DOBERMANN, DOG_TYPE, DOG_BREED, NAME, ADD, DOG_TYPE_FLUFFY, DOG_TYPE_BEST_FAMILY, DOG_TYPE_SMARTEST, DOG_TYPE_BEST_GUARD, DOG_TYPE_KID_FRIENDLY, DOG_TYPE_BEST_WATCH, DOG_TYPE_EASY_TO_TRAIN, DOG_TYPE_LOW_SHEDDING, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"LOGIN\":\"Вход\",\"EMAIL\":\"Имейл\",\"PASSWORD\":\"Парола\",\"FORGOT_PASSWORD\":\"Забравена парола\",\"DONT_HAVE_A_PROFILE\":\"Нямаш профил\",\"FULL_NAME\":\"Име и фамилия\",\"CONFIRM_PASSWORD\":\"Потвърди паролата\",\"REGISTER\":\"Регистрация\",\"ALREADY_HAVE_A_PROFILE\":\"Вече имам профил\",\"YOUR_REGISTRATION_HAS_BEEN_SUCCESSFULLY_COMPLETED\":\"Вашата регистрация завърши успешно.\",\"CHECK_YOUR_EMAIL_FOR_CONFIRMATION_LINK\":\"Проверете имейл-а си за линк за потвърждение.\",\"SWITCH_TO\":\"Превключи на\",\"ENGLISH\":\"Английски\",\"BULGARIAN\":\"Български\",\"HOME\":\"Начало\",\"DOGS\":\"Кучета\",\"SHOPS\":\"Магазини\",\"LOGOUT\":\"Изход\",\"OFFERS\":\"Предлага\",\"DOG_TYPE_HYPOALLERGENIC\":\"Хипоалергенни\",\"DOG_BREED_GERMAN_SPITZ\":\"Немски Шпиц\",\"DOG_BREED_GERMAN_SHEPHERD\":\"Немска Овчарка\",\"DOG_BREED_BULLDOG\":\"Булдог\",\"DOG_BREED_POODLE\":\"Пудел\",\"DOG_BREED_LABRADOR_RETRIEVER\":\"Лабрадор Ретривър\",\"DOG_BREED_GOLDEN_RETRIEVER\":\"Голдън Ретривър\",\"DOG_BREED_BEAGLE\":\"Бийгъл\",\"DOG_BREED_YORKSHIRE_TERRIER\":\"Йоркширски Териер\",\"DOG_BREED_DACHSHUND\":\"Дакел\",\"DOG_BREED_CHIHUAHUA\":\"Чихуахуа\",\"DOG_BREED_PUG\":\"Мопс\",\"DOG_BREED_FRENCH_BULLDOG\":\"Френски Булдог\",\"DOG_BREED_SIBERIAN_HUSKY\":\"Сибирско Хъски\",\"DOG_BREED_BOXER\":\"Боксер\",\"DOG_BREED_AUSTRALIAN_SHEPHERD\":\"Австралийска Овчарка\",\"DOG_BREED_GREYHOUND\":\"Хрътка\",\"DOG_BREED_ROTTWEILER\":\"Ротвайлер\",\"DOG_BREED_POMERANIAN\":\"Померански\",\"DOG_BREED_DALMATIAN\":\"Далматинец\",\"DOG_BREED_SHIBA_INU\":\"Шиба Ину\",\"DOG_BREED_SAMOYED\":\"Самоед\",\"DOG_BREED_DOBERMANN\":\"Доберман\",\"DOG_TYPE\":\"Вид на кучето\",\"DOG_BREED\":\"Порода\",\"NAME\":\"Име\",\"ADD\":\"Добави\",\"DOG_TYPE_FLUFFY\":\"Пухкави\",\"DOG_TYPE_BEST_FAMILY\":\"Семейни\",\"DOG_TYPE_SMARTEST\":\"Умни\",\"DOG_TYPE_BEST_GUARD\":\"Добри за охрана\",\"DOG_TYPE_KID_FRIENDLY\":\"Дружелюбни към деца\",\"DOG_TYPE_BEST_WATCH\":\"Най-добри за охрана\",\"DOG_TYPE_EASY_TO_TRAIN\":\"Лесни за дресировка\",\"DOG_TYPE_LOW_SHEDDING\":\"Слабо обезкосмяващи се\"}");

/***/ }),

/***/ "./ClientApp/locales/en.json":
/*!***********************************!*\
  !*** ./ClientApp/locales/en.json ***!
  \***********************************/
/*! exports provided: LOGIN, EMAIL, PASSWORD, FORGOT_PASSWORD, DONT_HAVE_A_PROFILE, FULL_NAME, CONFIRM_PASSWORD, REGISTER, ALREADY_HAVE_A_PROFILE, YOUR_REGISTRATION_HAS_BEEN_SUCCESSFULLY_COMPLETED, CHECK_YOUR_EMAIL_FOR_CONFIRMATION_LINK, SWITCH_TO, ENGLISH, BULGARIAN, HOME, DOGS, SHOPS, LOGOUT, OFFERS, DOG_TYPE_HYPOALLERGENIC, DOG_BREED_GERMAN_SPITZ, DOG_BREED_GERMAN_SHEPHERD, DOG_BREED_BULLDOG, DOG_BREED_POODLE, DOG_BREED_LABRADOR_RETRIEVER, DOG_BREED_GOLDEN_RETRIEVER, DOG_BREED_BEAGLE, DOG_BREED_YORKSHIRE_TERRIER, DOG_BREED_DACHSHUND, DOG_BREED_CHIHUAHUA, DOG_BREED_PUG, DOG_BREED_FRENCH_BULLDOG, DOG_BREED_SIBERIAN_HUSKY, DOG_BREED_BOXER, DOG_BREED_AUSTRALIAN_SHEPHERD, DOG_BREED_GREYHOUND, DOG_BREED_ROTTWEILER, DOG_BREED_POMERANIAN, DOG_BREED_DALMATIAN, DOG_BREED_SHIBA_INU, DOG_BREED_SAMOYED, DOG_BREED_DOBERMANN, DOG_TYPE, DOG_BREED, NAME, ADD, DOG_TYPE_FLUFFY, DOG_TYPE_BEST_FAMILY, DOG_TYPE_SMARTEST, DOG_TYPE_BEST_GUARD, DOG_TYPE_KID_FRIENDLY, DOG_TYPE_BEST_WATCH, DOG_TYPE_EASY_TO_TRAIN, DOG_TYPE_LOW_SHEDDING, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"LOGIN\":\"Login\",\"EMAIL\":\"Email\",\"PASSWORD\":\"Password\",\"FORGOT_PASSWORD\":\"Forgot password\",\"DONT_HAVE_A_PROFILE\":\"Don't have a profile\",\"FULL_NAME\":\"Full name\",\"CONFIRM_PASSWORD\":\"Confirm password\",\"REGISTER\":\"Register\",\"ALREADY_HAVE_A_PROFILE\":\"Already have a profile\",\"YOUR_REGISTRATION_HAS_BEEN_SUCCESSFULLY_COMPLETED\":\"Your registration has been successfully completed.\",\"CHECK_YOUR_EMAIL_FOR_CONFIRMATION_LINK\":\"Check your email for confirmation link.\",\"SWITCH_TO\":\"Switch to\",\"ENGLISH\":\"English\",\"BULGARIAN\":\"Bulgarian\",\"HOME\":\"Home\",\"DOGS\":\"Dogs\",\"SHOPS\":\"Shops\",\"LOGOUT\":\"Logout\",\"OFFERS\":\"Offers\",\"DOG_TYPE_HYPOALLERGENIC\":\"Hypoallergenic\",\"DOG_BREED_GERMAN_SPITZ\":\"German Spitz\",\"DOG_BREED_GERMAN_SHEPHERD\":\"German Shepherd\",\"DOG_BREED_BULLDOG\":\"Bulldog\",\"DOG_BREED_POODLE\":\"Poodle\",\"DOG_BREED_LABRADOR_RETRIEVER\":\"Labrador Retriever\",\"DOG_BREED_GOLDEN_RETRIEVER\":\"Golden Retriever\",\"DOG_BREED_BEAGLE\":\"Beagle\",\"DOG_BREED_YORKSHIRE_TERRIER\":\"Yorkshire Terrier\",\"DOG_BREED_DACHSHUND\":\"Dachshund\",\"DOG_BREED_CHIHUAHUA\":\"Chihuahua\",\"DOG_BREED_PUG\":\"Pug\",\"DOG_BREED_FRENCH_BULLDOG\":\"French Bulldog\",\"DOG_BREED_SIBERIAN_HUSKY\":\"Siberian Husky\",\"DOG_BREED_BOXER\":\"Boxer\",\"DOG_BREED_AUSTRALIAN_SHEPHERD\":\"Australian Shepherd\",\"DOG_BREED_GREYHOUND\":\"Greyhound\",\"DOG_BREED_ROTTWEILER\":\"Rottweiler\",\"DOG_BREED_POMERANIAN\":\"Pomeranian\",\"DOG_BREED_DALMATIAN\":\"Dalmatian\",\"DOG_BREED_SHIBA_INU\":\"Shiba Inu\",\"DOG_BREED_SAMOYED\":\"Samoyed\",\"DOG_BREED_DOBERMANN\":\"Dobermann\",\"DOG_TYPE\":\"Dog type\",\"DOG_BREED\":\"Breed\",\"NAME\":\"Name\",\"ADD\":\"Add\",\"DOG_TYPE_FLUFFY\":\"Fluffy\",\"DOG_TYPE_BEST_FAMILY\":\"Best family\",\"DOG_TYPE_SMARTEST\":\"Smartest\",\"DOG_TYPE_BEST_GUARD\":\"Best guard\",\"DOG_TYPE_KID_FRIENDLY\":\"Kid friendly\",\"DOG_TYPE_BEST_WATCH\":\"Best watch\",\"DOG_TYPE_EASY_TO_TRAIN\":\"Easy to train\",\"DOG_TYPE_LOW_SHEDDING\":\"Low shedding\"}");

/***/ }),

/***/ "./ClientApp/locales/i18n.js":
/*!***********************************!*\
  !*** ./ClientApp/locales/i18n.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _vue = _interopRequireDefault(__webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm.js"));

var _en = _interopRequireDefault(__webpack_require__(/*! ./en.json */ "./ClientApp/locales/en.json"));

var _bg = _interopRequireDefault(__webpack_require__(/*! ./bg.json */ "./ClientApp/locales/bg.json"));

var _vueI18n = _interopRequireDefault(__webpack_require__(/*! vue-i18n */ "./node_modules/vue-i18n/dist/vue-i18n.esm.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

// ------------------------------------------------------------------------------
// <auto-generated>
//     This code was generated by Emeraude Client Builder.
//     Changes to this file may cause incorrect behavior and will be lost if
//     the code is regenerated.
// </auto-generated>
// ------------------------------------------------------------------------------
_vue["default"].use(_vueI18n["default"]);

var messages = {
  'en': _en["default"],
  'bg': _bg["default"]
};
var i18n = new _vueI18n["default"]({
  locale: 'en',
  fallbackLocale: 'en',
  messages: messages
});
var _default = i18n;
exports["default"] = _default;

/***/ }),

/***/ "./ClientApp/main.js":
/*!***************************!*\
  !*** ./ClientApp/main.js ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "router", {
  enumerable: true,
  get: function get() {
    return _router["default"];
  }
});
Object.defineProperty(exports, "store", {
  enumerable: true,
  get: function get() {
    return _store["default"];
  }
});
exports.app = void 0;

var _vue = _interopRequireDefault(__webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm.js"));

var _router = _interopRequireDefault(__webpack_require__(/*! ./router */ "./ClientApp/router/index.js"));

var _store = _interopRequireDefault(__webpack_require__(/*! ./store */ "./ClientApp/store/index.js"));

var _i18n = _interopRequireDefault(__webpack_require__(/*! ./locales/i18n */ "./ClientApp/locales/i18n.js"));

var _bootstrapVue = _interopRequireDefault(__webpack_require__(/*! bootstrap-vue */ "./node_modules/bootstrap-vue/esm/index.js"));

var _App = _interopRequireDefault(__webpack_require__(/*! ./App.vue */ "./ClientApp/App.vue"));

__webpack_require__(/*! ./shared/filters */ "./ClientApp/shared/filters.js");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

_vue["default"].use(_bootstrapVue["default"]);

var app = new _vue["default"]({
  i18n: _i18n["default"],
  router: _router["default"],
  store: _store["default"],
  render: function render(h) {
    return h(_App["default"]);
  }
});
exports.app = app;

/***/ }),

/***/ "./ClientApp/mixins/general/generalMixin.js":
/*!**************************************************!*\
  !*** ./ClientApp/mixins/general/generalMixin.js ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var _default = {
  data: function data() {
    return {};
  },
  computed: {
    languagePrefix: function languagePrefix() {
      return this.$store.getters.languageCode === 'en' ? "" : "/" + this.$store.getters.languageCode;
    }
  },
  methods: {
    getRoute: function getRoute() {
      var route = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';
      return this.languagePrefix + route;
    },
    applyTranslationPropertiesToList: function applyTranslationPropertiesToList(list) {
      for (var i = 0; i < list.length; i++) {
        list[i].translation = this.$t(list[i].nameKey);
      }

      return list;
    },
    redirectToRoute: function redirectToRoute(route) {
      var clean = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      window.location.href = this.getRoute(route, clean);
    }
  }
};
exports["default"] = _default;

/***/ }),

/***/ "./ClientApp/pages/dogs/Dogs.vue":
/*!***************************************!*\
  !*** ./ClientApp/pages/dogs/Dogs.vue ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Dogs_vue_vue_type_template_id_e5d52ca6_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Dogs.vue?vue&type=template&id=e5d52ca6&scoped=true& */ "./ClientApp/pages/dogs/Dogs.vue?vue&type=template&id=e5d52ca6&scoped=true&");
/* harmony import */ var _Dogs_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Dogs.vue?vue&type=script&lang=js& */ "./ClientApp/pages/dogs/Dogs.vue?vue&type=script&lang=js&");
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _Dogs_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _Dogs_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Dogs_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Dogs_vue_vue_type_template_id_e5d52ca6_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Dogs_vue_vue_type_template_id_e5d52ca6_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "e5d52ca6",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "ClientApp/pages/dogs/Dogs.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./ClientApp/pages/dogs/Dogs.vue?vue&type=script&lang=js&":
/*!****************************************************************!*\
  !*** ./ClientApp/pages/dogs/Dogs.vue?vue&type=script&lang=js& ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Dogs_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib??vue-loader-options!./Dogs.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./ClientApp/pages/dogs/Dogs.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Dogs_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Dogs_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Dogs_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Dogs_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Dogs_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./ClientApp/pages/dogs/Dogs.vue?vue&type=template&id=e5d52ca6&scoped=true&":
/*!**********************************************************************************!*\
  !*** ./ClientApp/pages/dogs/Dogs.vue?vue&type=template&id=e5d52ca6&scoped=true& ***!
  \**********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Dogs_vue_vue_type_template_id_e5d52ca6_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib??vue-loader-options!./Dogs.vue?vue&type=template&id=e5d52ca6&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/pages/dogs/Dogs.vue?vue&type=template&id=e5d52ca6&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Dogs_vue_vue_type_template_id_e5d52ca6_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Dogs_vue_vue_type_template_id_e5d52ca6_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./ClientApp/pages/home/Home.vue":
/*!***************************************!*\
  !*** ./ClientApp/pages/home/Home.vue ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Home_vue_vue_type_template_id_117602ad_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Home.vue?vue&type=template&id=117602ad&scoped=true& */ "./ClientApp/pages/home/Home.vue?vue&type=template&id=117602ad&scoped=true&");
/* harmony import */ var _Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Home.vue?vue&type=script&lang=js& */ "./ClientApp/pages/home/Home.vue?vue&type=script&lang=js&");
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Home_vue_vue_type_template_id_117602ad_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Home_vue_vue_type_template_id_117602ad_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "117602ad",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "ClientApp/pages/home/Home.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./ClientApp/pages/home/Home.vue?vue&type=script&lang=js&":
/*!****************************************************************!*\
  !*** ./ClientApp/pages/home/Home.vue?vue&type=script&lang=js& ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib??vue-loader-options!./Home.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./ClientApp/pages/home/Home.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./ClientApp/pages/home/Home.vue?vue&type=template&id=117602ad&scoped=true&":
/*!**********************************************************************************!*\
  !*** ./ClientApp/pages/home/Home.vue?vue&type=template&id=117602ad&scoped=true& ***!
  \**********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_template_id_117602ad_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib??vue-loader-options!./Home.vue?vue&type=template&id=117602ad&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/pages/home/Home.vue?vue&type=template&id=117602ad&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_template_id_117602ad_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Home_vue_vue_type_template_id_117602ad_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./ClientApp/pages/shops/Shops.vue":
/*!*****************************************!*\
  !*** ./ClientApp/pages/shops/Shops.vue ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Shops_vue_vue_type_template_id_610a96c9_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Shops.vue?vue&type=template&id=610a96c9&scoped=true& */ "./ClientApp/pages/shops/Shops.vue?vue&type=template&id=610a96c9&scoped=true&");
/* harmony import */ var _Shops_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Shops.vue?vue&type=script&lang=js& */ "./ClientApp/pages/shops/Shops.vue?vue&type=script&lang=js&");
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _Shops_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _Shops_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Shops_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Shops_vue_vue_type_template_id_610a96c9_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Shops_vue_vue_type_template_id_610a96c9_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "610a96c9",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "ClientApp/pages/shops/Shops.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./ClientApp/pages/shops/Shops.vue?vue&type=script&lang=js&":
/*!******************************************************************!*\
  !*** ./ClientApp/pages/shops/Shops.vue?vue&type=script&lang=js& ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Shops_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/babel-loader/lib!../../../node_modules/vue-loader/lib??vue-loader-options!./Shops.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./ClientApp/pages/shops/Shops.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Shops_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Shops_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Shops_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Shops_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_node_modules_vue_loader_lib_index_js_vue_loader_options_Shops_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "./ClientApp/pages/shops/Shops.vue?vue&type=template&id=610a96c9&scoped=true&":
/*!************************************************************************************!*\
  !*** ./ClientApp/pages/shops/Shops.vue?vue&type=template&id=610a96c9&scoped=true& ***!
  \************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Shops_vue_vue_type_template_id_610a96c9_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../node_modules/vue-loader/lib??vue-loader-options!./Shops.vue?vue&type=template&id=610a96c9&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/pages/shops/Shops.vue?vue&type=template&id=610a96c9&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Shops_vue_vue_type_template_id_610a96c9_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Shops_vue_vue_type_template_id_610a96c9_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./ClientApp/router/index.js":
/*!***********************************!*\
  !*** ./ClientApp/router/index.js ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _vue = _interopRequireDefault(__webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm.js"));

var _vueRouter = _interopRequireDefault(__webpack_require__(/*! vue-router */ "./node_modules/vue-router/dist/vue-router.esm.js"));

var _index = _interopRequireDefault(__webpack_require__(/*! ../store/index */ "./ClientApp/store/index.js"));

var _routes = __webpack_require__(/*! ./routes */ "./ClientApp/router/routes.js");

var _emeraudeInitialStateProcessors = __webpack_require__(/*! emeraude-initial-state-processors */ "./node_modules/emeraude-initial-state-processors/src/index.js");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

_vue["default"].use(_vueRouter["default"]);

var router = new _vueRouter["default"]({
  mode: 'history',
  routes: _routes.routes
});
(0, _emeraudeInitialStateProcessors.useEmPageInterceptors)(router, _index["default"]);
var _default = router;
exports["default"] = _default;

/***/ }),

/***/ "./ClientApp/router/routes.js":
/*!************************************!*\
  !*** ./ClientApp/router/routes.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.routes = void 0;

function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

function _getRequireWildcardCache() { if (typeof WeakMap !== "function") return null; var cache = new WeakMap(); _getRequireWildcardCache = function _getRequireWildcardCache() { return cache; }; return cache; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

// ------------------------------------------------------------------------------
// <auto-generated>
//     This code was generated by Emeraude Client Builder.
//     Changes to this file may cause incorrect behavior and will be lost if
//     the code is regenerated.
// </auto-generated>
// ------------------------------------------------------------------------------
var Home = function Home() {
  return Promise.resolve().then(function () {
    return _interopRequireWildcard(__webpack_require__(/*! ../pages/home/Home */ "./ClientApp/pages/home/Home.vue"));
  });
};

var Dogs = function Dogs() {
  return Promise.resolve().then(function () {
    return _interopRequireWildcard(__webpack_require__(/*! ../pages/dogs/Dogs */ "./ClientApp/pages/dogs/Dogs.vue"));
  });
};

var Shops = function Shops() {
  return Promise.resolve().then(function () {
    return _interopRequireWildcard(__webpack_require__(/*! ../pages/shops/Shops */ "./ClientApp/pages/shops/Shops.vue"));
  });
};

var languageRoutePrefix = '/:lang(bg)?';
var routes = [{
  name: 'Home',
  path: "".concat(languageRoutePrefix, "/"),
  component: Home
}, {
  name: 'Dogs',
  path: "".concat(languageRoutePrefix, "/dogs"),
  component: Dogs
}, {
  name: 'Shops',
  path: "".concat(languageRoutePrefix, "/shops"),
  component: Shops
}];
exports.routes = routes;

/***/ }),

/***/ "./ClientApp/shared/filters.js":
/*!*************************************!*\
  !*** ./ClientApp/shared/filters.js ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _vue = _interopRequireDefault(__webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm.js"));

var _helpers = __webpack_require__(/*! ../utils/helpers */ "./ClientApp/utils/helpers.js");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

_vue["default"].filter('date', function (value) {
  return (0, _helpers.formatDate)(value);
});

_vue["default"].filter('time', function (value) {
  return (0, _helpers.formatTime)(value);
});

/***/ }),

/***/ "./ClientApp/store/index.js":
/*!**********************************!*\
  !*** ./ClientApp/store/index.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _vue = _interopRequireDefault(__webpack_require__(/*! vue */ "./node_modules/vue/dist/vue.runtime.esm.js"));

var _vuex = _interopRequireDefault(__webpack_require__(/*! vuex */ "./node_modules/vuex/dist/vuex.esm.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

_vue["default"].use(_vuex["default"]);

var getters = {};
var mutations = {
  SET_DATA: function SET_DATA(state, value) {
    state.data = value;
  }
};
var actions = {
  updateData: function updateData(context, value) {
    context.commit('SET_DATA', value);
  }
};
var store = new _vuex["default"].Store({
  getters: getters,
  mutations: mutations,
  actions: actions
});
var _default = store;
exports["default"] = _default;

/***/ }),

/***/ "./ClientApp/utils/helpers.js":
/*!************************************!*\
  !*** ./ClientApp/utils/helpers.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.newGuid = newGuid;
exports.formatDate = formatDate;
exports.formatTime = formatTime;
exports.getWeekdayFromDate = getWeekdayFromDate;
exports.getKeyByValue = getKeyByValue;

var _moment = _interopRequireDefault(__webpack_require__(/*! moment */ "./node_modules/moment/moment.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

function newGuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = Math.random() * 16 | 0,
        v = c == 'x' ? r : r & 0x3 | 0x8;
    return v.toString(16);
  });
}

;

function formatDate(date) {
  return (0, _moment["default"])(date).format('DD/MM/YYYY');
}

function formatTime(time) {
  return (0, _moment["default"])(time, 'HH:mm:ss').format("HH:mm");
}

function getWeekdayFromDate(date) {
  var weekday = new Array(7);
  weekday[0] = "SUNDAY";
  weekday[1] = "MONDAY";
  weekday[2] = "TUESDAY";
  weekday[3] = "WEDNESDAY";
  weekday[4] = "THURSDAY";
  weekday[5] = "FRIDAY";
  weekday[6] = "SATURDAY";
  return weekday[(0, _moment["default"])(date).format('d')];
}

function getKeyByValue(object, value) {
  return Object.keys(object).find(function (key) {
    return object[key] === value;
  });
}

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./ClientApp/App.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/App.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _emeraudeInitialStateProcessors = __webpack_require__(/*! emeraude-initial-state-processors */ "./node_modules/emeraude-initial-state-processors/src/index.js");

//
//
//
//
//
//
var _default = {
  data: function data() {
    return {};
  },
  mixins: [_emeraudeInitialStateProcessors.initialStateMixin],
  mounted: function mounted() {}
};
exports["default"] = _default;

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./ClientApp/components/forms/EnumBSelect.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/components/forms/EnumBSelect.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _endpoints = __webpack_require__(/*! ../../api/endpoints */ "./ClientApp/api/endpoints.js");

//
//
//
//
//
//
//
//
var _default = {
  name: "EnumSelect",
  data: function data() {
    return {
      options: []
    };
  },
  props: {
    enumType: String,
    value: Number
  },
  methods: {
    updateValue: function updateValue(value) {
      this.value = value;
      this.$emit('input', this.value);
    },
    loadOptions: function loadOptions() {
      var _this = this;

      var self = this;

      _endpoints.enumServiceAgent.getEnumValueList(this.enumType).then(function (data) {
        for (var i = 0; i < data.length; i++) {
          _this.options.push({
            key: data[i].key,
            value: data[i].value,
            translatedValue: self.$t(data[i].key)
          });
        }
      })["catch"](function (error) {
        console.log(error);
      });
    }
  },
  mounted: function mounted() {
    this.loadOptions();
  }
};
exports["default"] = _default;

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./ClientApp/components/static-content/HomePageStaticContent.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/components/static-content/HomePageStaticContent.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
var _default = {
  name: "HomePageStaticContent",
  props: {
    languageId: {
      type: Number,
      "default": 1
    }
  }
};
exports["default"] = _default;

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./ClientApp/layouts/Layout.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/layouts/Layout.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _Navbar = _interopRequireDefault(__webpack_require__(/*! ./Navbar */ "./ClientApp/layouts/Navbar.vue"));

var _Footer = _interopRequireDefault(__webpack_require__(/*! ./Footer */ "./ClientApp/layouts/Footer.vue"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

//
//
//
//
//
//
//
//
//
//
//
var _default = {
  data: function data() {
    return {};
  },
  components: {
    TopNavbar: _Navbar["default"],
    LayoutFooter: _Footer["default"]
  }
};
exports["default"] = _default;

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./ClientApp/layouts/Navbar.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/layouts/Navbar.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _generalMixin = _interopRequireDefault(__webpack_require__(/*! ../mixins/general/generalMixin */ "./ClientApp/mixins/general/generalMixin.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
var _default = {
  mixins: [_generalMixin["default"]],
  computed: {
    isAuthenticated: function isAuthenticated() {
      if (this.$store.getters.user !== undefined) {
        return this.$store.getters.user.isAuthenticated;
      }

      return false;
    },
    userName: function userName() {
      if (this.$store.getters.user !== undefined) {
        return this.$store.getters.user.name.split(" ")[0];
      }

      return '';
    },
    stateString: function stateString() {
      return this.$store.getters.stateString;
    },
    languageReverseLink: function languageReverseLink() {
      var _this$$route$params$l;

      var languageCode = (_this$$route$params$l = this.$route.params.lang) !== null && _this$$route$params$l !== void 0 ? _this$$route$params$l : 'en';

      if (languageCode === 'en') {
        return '/bg';
      } else if (languageCode === 'bg') {
        return '/';
      } else {
        return '/bg';
      }
    },
    languageReverseName: function languageReverseName() {
      var _this$$route$params$l2;

      var languageCode = (_this$$route$params$l2 = this.$route.params.lang) !== null && _this$$route$params$l2 !== void 0 ? _this$$route$params$l2 : 'en';

      if (languageCode === 'en') {
        return 'BULGARIAN';
      } else if (languageCode === 'bg') {
        return 'ENGLISH';
      } else {
        return 'BULGARIAN';
      }
    }
  },
  methods: {}
};
exports["default"] = _default;

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./ClientApp/pages/dogs/Dogs.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/pages/dogs/Dogs.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _Layout = _interopRequireDefault(__webpack_require__(/*! ../../layouts/Layout */ "./ClientApp/layouts/Layout.vue"));

var _EnumBSelect = _interopRequireDefault(__webpack_require__(/*! ../../components/forms/EnumBSelect */ "./ClientApp/components/forms/EnumBSelect.vue"));

var _endpoints = __webpack_require__(/*! ../../api/endpoints */ "./ClientApp/api/endpoints.js");

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
var _default = {
  name: "Dogs",
  components: {
    Layout: _Layout["default"],
    EnumBSelect: _EnumBSelect["default"]
  },
  data: function data() {
    return {
      newDog: {
        name: '',
        type: 1,
        breed: 1
      }
    };
  },
  computed: {
    dogs: function dogs() {
      if (this.$store.getters.viewModel.dogs !== undefined) {
        return this.$store.getters.viewModel.dogs;
      }

      return [];
    }
  },
  methods: {
    addDog: function addDog() {
      var self = this;

      _endpoints.dogsServiceAgent.addDog(self.newDog).then(function () {
        location.reload();
      })["catch"](function (error) {
        console.log(error);
      });
    },
    resetNewDog: function resetNewDog() {
      this.newDog = {
        name: '',
        type: 1,
        breed: 1
      };
    }
  },
  mounted: function mounted() {}
};
exports["default"] = _default;

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./ClientApp/pages/home/Home.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/pages/home/Home.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _Layout = _interopRequireDefault(__webpack_require__(/*! ../../layouts/Layout */ "./ClientApp/layouts/Layout.vue"));

var _HomePageStaticContent = _interopRequireDefault(__webpack_require__(/*! ../../components/static-content/HomePageStaticContent */ "./ClientApp/components/static-content/HomePageStaticContent.vue"));

var _generalMixin = _interopRequireDefault(__webpack_require__(/*! ../../mixins/general/generalMixin */ "./ClientApp/mixins/general/generalMixin.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

//
//
//
//
//
//
//
//
var _default = {
  name: "Home",
  components: {
    Layout: _Layout["default"],
    HomePageStaticContent: _HomePageStaticContent["default"]
  },
  mixins: [_generalMixin["default"]],
  data: function data() {
    return {};
  },
  computed: {
    languageId: function languageId() {
      return this.$store.getters.languageId;
    }
  },
  methods: {},
  mounted: function mounted() {}
};
exports["default"] = _default;

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js!./node_modules/vue-loader/lib/index.js?!./ClientApp/pages/shops/Shops.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/pages/shops/Shops.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;

var _Layout = _interopRequireDefault(__webpack_require__(/*! ../../layouts/Layout */ "./ClientApp/layouts/Layout.vue"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
var _default = {
  name: "Shops",
  components: {
    Layout: _Layout["default"]
  },
  data: function data() {
    return {};
  },
  computed: {
    shops: function shops() {
      if (this.$store.getters.viewModel.shops !== undefined) {
        return this.$store.getters.viewModel.shops;
      }

      return [];
    }
  },
  methods: {},
  mounted: function mounted() {}
};
exports["default"] = _default;

/***/ }),

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-in": "./node_modules/moment/locale/en-in.js",
	"./en-in.js": "./node_modules/moment/locale/en-in.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./en-sg": "./node_modules/moment/locale/en-sg.js",
	"./en-sg.js": "./node_modules/moment/locale/en-sg.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fil": "./node_modules/moment/locale/fil.js",
	"./fil.js": "./node_modules/moment/locale/fil.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./ga": "./node_modules/moment/locale/ga.js",
	"./ga.js": "./node_modules/moment/locale/ga.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-deva": "./node_modules/moment/locale/gom-deva.js",
	"./gom-deva.js": "./node_modules/moment/locale/gom-deva.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it-ch": "./node_modules/moment/locale/it-ch.js",
	"./it-ch.js": "./node_modules/moment/locale/it-ch.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ku": "./node_modules/moment/locale/ku.js",
	"./ku.js": "./node_modules/moment/locale/ku.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./oc-lnc": "./node_modules/moment/locale/oc-lnc.js",
	"./oc-lnc.js": "./node_modules/moment/locale/oc-lnc.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tk": "./node_modules/moment/locale/tk.js",
	"./tk.js": "./node_modules/moment/locale/tk.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-mo": "./node_modules/moment/locale/zh-mo.js",
	"./zh-mo.js": "./node_modules/moment/locale/zh-mo.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/App.vue?vue&type=template&id=67a9280a&":
/*!****************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/App.vue?vue&type=template&id=67a9280a& ***!
  \****************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "h-100 w-100" }, [_c("router-view")], 1)
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/components/forms/EnumBSelect.vue?vue&type=template&id=4a89a4cb&scoped=true&":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/components/forms/EnumBSelect.vue?vue&type=template&id=4a89a4cb&scoped=true& ***!
  \*****************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c(
        "b-select",
        {
          on: { input: _vm.updateValue },
          model: {
            value: _vm.value,
            callback: function($$v) {
              _vm.value = $$v
            },
            expression: "value"
          }
        },
        _vm._l(_vm.options, function(option, index) {
          return _c(
            "b-select-option",
            { key: _vm.enumType + index, attrs: { value: option.value } },
            [_vm._v(_vm._s(option.translatedValue))]
          )
        }),
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/components/static-content/HomePageStaticContent.vue?vue&type=template&id=25af3c4a&":
/*!************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/components/static-content/HomePageStaticContent.vue?vue&type=template&id=25af3c4a& ***!
  \************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { attrs: { id: "static-content-home-page" } }, [
    _vm.languageId === 1 ? _c("div", [_vm._m(0)]) : _vm._e(),
    _vm._v(" "),
    _vm.languageId === 2 ? _c("div", [_vm._m(1)]) : _vm._e()
  ])
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-sm-6" }, [
        _c("div", { staticClass: "card" }, [
          _c("div", { staticClass: "card-body" }, [
            _c("h5", { staticClass: "card-title" }, [_vm._v("Authentication")]),
            _vm._v(" "),
            _c("p", { staticClass: "card-text" }, [
              _vm._v(
                "All authentication features like login, register, forgot password, reset password, confirm email and logout are provided."
              )
            ]),
            _vm._v(" "),
            _c(
              "a",
              { staticClass: "btn btn-primary", attrs: { href: "/login" } },
              [_vm._v("Log In")]
            )
          ])
        ])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "col-sm-6" }, [
        _c("div", { staticClass: "card" }, [
          _c("div", { staticClass: "card-body" }, [
            _c("h5", { staticClass: "card-title" }, [
              _vm._v("The auto CRUD and admin panel.")
            ]),
            _vm._v(" "),
            _c("p", { staticClass: "card-text" }, [
              _vm._v(
                "Administration comes out of the box and all features comes by inheritance the Emeraude classes."
              )
            ]),
            _vm._v(" "),
            _c(
              "a",
              { staticClass: "btn btn-primary", attrs: { href: "/admin" } },
              [_vm._v("Go To Administration")]
            )
          ])
        ])
      ])
    ])
  },
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "row" }, [
      _c("div", { staticClass: "col-sm-6" }, [
        _c("div", { staticClass: "card" }, [
          _c("div", { staticClass: "card-body" }, [
            _c("h5", { staticClass: "card-title" }, [
              _vm._v("Управление на профилите")
            ]),
            _vm._v(" "),
            _c("p", { staticClass: "card-text" }, [
              _vm._v(
                "Всички функционалности като вход, регистрация, забравена парола, промяна на парола, потвърждаване на имейл и изход от профил са предоставени."
              )
            ]),
            _vm._v(" "),
            _c(
              "a",
              { staticClass: "btn btn-primary", attrs: { href: "/login" } },
              [_vm._v("Влез В Профила")]
            )
          ])
        ])
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "col-sm-6" }, [
        _c("div", { staticClass: "card" }, [
          _c("div", { staticClass: "card-body" }, [
            _c("h5", { staticClass: "card-title" }, [
              _vm._v("Автоматичен CRUD и админ панел.")
            ]),
            _vm._v(" "),
            _c("p", { staticClass: "card-text" }, [
              _vm._v(
                "Администрацията идва автоматично, като основните и функционалности идват чрез наследяване на класовете на Emeraude."
              )
            ]),
            _vm._v(" "),
            _c(
              "a",
              { staticClass: "btn btn-primary", attrs: { href: "/admin" } },
              [_vm._v("Отиди В Администрацията")]
            )
          ])
        ])
      ])
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/layouts/Footer.vue?vue&type=template&id=39a21988&":
/*!***************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/layouts/Footer.vue?vue&type=template&id=39a21988& ***!
  \***************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _vm._m(0)
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", [
      _c("div", { staticClass: "container copyright pt-5 pb-5" }, [
        _c("div", { staticClass: "row w-100" }, [
          _c("div", { staticClass: "col-12" }),
          _vm._v(" "),
          _c("div", { staticClass: "col-12 text-center" }, [
            _c("p", { staticClass: "mb-0" }, [_vm._v("2020 © Emeraude")])
          ])
        ])
      ])
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/layouts/Layout.vue?vue&type=template&id=0d5a00d2&":
/*!***************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/layouts/Layout.vue?vue&type=template&id=0d5a00d2& ***!
  \***************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", [
    _c(
      "div",
      { staticClass: "p-3" },
      [
        _c("top-navbar"),
        _vm._v(" "),
        _c("div", [_vm._t("default")], 2),
        _vm._v(" "),
        _c("layout-footer")
      ],
      1
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/layouts/Navbar.vue?vue&type=template&id=4f578506&":
/*!***************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/layouts/Navbar.vue?vue&type=template&id=4f578506& ***!
  \***************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass:
        "d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom box-shadow"
    },
    [
      _vm._m(0),
      _vm._v(" "),
      _c(
        "nav",
        { staticClass: "my-2 my-md-0 mr-md-3" },
        [
          _c(
            "router-link",
            { staticClass: "p-2 text-dark", attrs: { to: _vm.getRoute("/") } },
            [_vm._v(_vm._s(_vm.$t("HOME")))]
          ),
          _vm._v(" "),
          _c(
            "router-link",
            {
              staticClass: "p-2 text-dark",
              attrs: { to: _vm.getRoute("/dogs") }
            },
            [_vm._v(_vm._s(_vm.$t("DOGS")))]
          ),
          _vm._v(" "),
          _c(
            "router-link",
            {
              staticClass: "p-2 text-dark",
              attrs: { to: _vm.getRoute("/shops") }
            },
            [_vm._v(_vm._s(_vm.$t("SHOPS")))]
          ),
          _vm._v(" "),
          _c(
            "a",
            {
              staticClass: "ml-2 btn btn-primary",
              attrs: { href: _vm.languageReverseLink }
            },
            [
              _vm._v(
                _vm._s(_vm.$t("SWITCH_TO")) +
                  " " +
                  _vm._s(_vm.$t(_vm.languageReverseName))
              )
            ]
          )
        ],
        1
      ),
      _vm._v(" "),
      !_vm.isAuthenticated
        ? _c(
            "a",
            {
              staticClass: "btn btn-outline-primary",
              attrs: { href: _vm.getRoute("/login") }
            },
            [_vm._v(_vm._s(_vm.$t("LOGIN")))]
          )
        : _c(
            "form",
            { attrs: { method: "post", action: "/logout" } },
            [
              _c(
                "b-button",
                { attrs: { variant: "primary", type: "submit" } },
                [_vm._v(_vm._s(_vm.$t("LOGOUT")))]
              )
            ],
            1
          )
    ]
  )
}
var staticRenderFns = [
  function() {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("h5", { staticClass: "my-0 mr-md-auto font-weight-normal" }, [
      _c("img", {
        staticClass: "navbar-logo",
        attrs: { src: "/assets/images/dogapp_logo_text.png" }
      })
    ])
  }
]
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/pages/dogs/Dogs.vue?vue&type=template&id=e5d52ca6&scoped=true&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/pages/dogs/Dogs.vue?vue&type=template&id=e5d52ca6&scoped=true& ***!
  \****************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("layout", [
    _c(
      "div",
      [
        _c(
          "b-row",
          [
            _c(
              "b-col",
              { attrs: { md: "6" } },
              [
                _c(
                  "b-form-group",
                  { attrs: { label: _vm.$t("NAME") } },
                  [
                    _c("b-input", {
                      model: {
                        value: _vm.newDog.name,
                        callback: function($$v) {
                          _vm.$set(_vm.newDog, "name", $$v)
                        },
                        expression: "newDog.name"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "b-form-group",
                  { attrs: { label: _vm.$t("DOG_TYPE") } },
                  [
                    _c("enum-b-select", {
                      attrs: { enumType: "EmDoggoDev.Domain.Common.DogType" },
                      model: {
                        value: _vm.newDog.type,
                        callback: function($$v) {
                          _vm.$set(_vm.newDog, "type", $$v)
                        },
                        expression: "newDog.type"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "b-form-group",
                  { attrs: { label: _vm.$t("DOG_BREED") } },
                  [
                    _c("enum-b-select", {
                      attrs: { enumType: "EmDoggoDev.Domain.Common.DogBreed" },
                      model: {
                        value: _vm.newDog.breed,
                        callback: function($$v) {
                          _vm.$set(_vm.newDog, "breed", $$v)
                        },
                        expression: "newDog.breed"
                      }
                    })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "b-button",
                  { attrs: { variant: "primary" }, on: { click: _vm.addDog } },
                  [_vm._v(_vm._s(_vm.$t("ADD")))]
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "b-col",
              [
                _c(
                  "b-row",
                  _vm._l(_vm.dogs, function(dog) {
                    return _c(
                      "b-col",
                      { key: dog.id, staticClass: "mb-2", attrs: { md: "6" } },
                      [
                        _c(
                          "b-card",
                          {
                            staticClass: "text-center",
                            attrs: { title: dog.name }
                          },
                          [_c("h1", { staticClass: "mdi mdi-dog" })]
                        )
                      ],
                      1
                    )
                  }),
                  1
                )
              ],
              1
            )
          ],
          1
        )
      ],
      1
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/pages/home/Home.vue?vue&type=template&id=117602ad&scoped=true&":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/pages/home/Home.vue?vue&type=template&id=117602ad&scoped=true& ***!
  \****************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("layout", [
    _c(
      "div",
      [
        _c("home-page-static-content", {
          attrs: { "language-id": _vm.languageId }
        })
      ],
      1
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./ClientApp/pages/shops/Shops.vue?vue&type=template&id=610a96c9&scoped=true&":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./ClientApp/pages/shops/Shops.vue?vue&type=template&id=610a96c9&scoped=true& ***!
  \******************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "layout",
    [
      _c(
        "b-row",
        _vm._l(_vm.shops, function(shop) {
          return _c(
            "b-col",
            { key: shop.id, staticClass: "h-100", attrs: { md: "4" } },
            [
              _c(
                "b-card",
                { attrs: { title: shop.name, "sub-title": _vm.$t("OFFERS") } },
                [
                  _c(
                    "ul",
                    _vm._l(shop.foods, function(food) {
                      return _c("li", { key: food.id }, [
                        _vm._v(_vm._s(food.food.name))
                      ])
                    }),
                    0
                  )
                ]
              )
            ],
            1
          )
        }),
        1
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "C:\\Users\\gsk567\\AppData\\Local\\Temp\\tmp-19756fHvNZCUjI7Iq.client.js":
/*!**************************************************************************!*\
  !*** C:/Users/gsk567/AppData/Local/Temp/tmp-19756fHvNZCUjI7Iq.client.js ***!
  \**************************************************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_GitHubWorkspace_Emeraude_sample_EmDoggoDev_src_web_EmDoggoDev_ClientApp_main_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ClientApp/main.js */ "./ClientApp/main.js");
/* harmony import */ var D_GitHubWorkspace_Emeraude_sample_EmDoggoDev_src_web_EmDoggoDev_ClientApp_main_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(D_GitHubWorkspace_Emeraude_sample_EmDoggoDev_src_web_EmDoggoDev_ClientApp_main_js__WEBPACK_IMPORTED_MODULE_0__);

D_GitHubWorkspace_Emeraude_sample_EmDoggoDev_src_web_EmDoggoDev_ClientApp_main_js__WEBPACK_IMPORTED_MODULE_0__["store"].replaceState(__INITIAL_STATE__);
D_GitHubWorkspace_Emeraude_sample_EmDoggoDev_src_web_EmDoggoDev_ClientApp_main_js__WEBPACK_IMPORTED_MODULE_0__["router"].onReady(() => {
    D_GitHubWorkspace_Emeraude_sample_EmDoggoDev_src_web_EmDoggoDev_ClientApp_main_js__WEBPACK_IMPORTED_MODULE_0__["router"].beforeResolve((to, from, next) => {
        const matched = D_GitHubWorkspace_Emeraude_sample_EmDoggoDev_src_web_EmDoggoDev_ClientApp_main_js__WEBPACK_IMPORTED_MODULE_0__["router"].getMatchedComponents(to);
        const prevMatched = D_GitHubWorkspace_Emeraude_sample_EmDoggoDev_src_web_EmDoggoDev_ClientApp_main_js__WEBPACK_IMPORTED_MODULE_0__["router"].getMatchedComponents(from);

        let diffed = false;
        const activated = matched.filter((c, i) => {
            return diffed || (diffed = (prevMatched[i] !== c))
        });

        if (!activated.length) {
            return next()
        }

        Promise.all(activated.map(c => {
            if (c.asyncData) {
                return c.asyncData({ store: D_GitHubWorkspace_Emeraude_sample_EmDoggoDev_src_web_EmDoggoDev_ClientApp_main_js__WEBPACK_IMPORTED_MODULE_0__["store"], route: to })
            }
        })).then(() => {
            next()
        }).catch(next)
    });
    D_GitHubWorkspace_Emeraude_sample_EmDoggoDev_src_web_EmDoggoDev_ClientApp_main_js__WEBPACK_IMPORTED_MODULE_0__["app"].$mount('#emeraude-app');
});

/***/ })

},[["C:\\Users\\gsk567\\AppData\\Local\\Temp\\tmp-19756fHvNZCUjI7Iq.client.js","manifest.client","vendors.client"]]]);